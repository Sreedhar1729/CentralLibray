sap.ui.define(
    [     "./BaseController",
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("com.app.centrallibrary.controller.IssuedBooks", {
        onInit: function() {
        },
        

      });
    }
  );
  